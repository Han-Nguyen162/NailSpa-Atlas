import CrawlerDashboard from "@/components/CrawlerDashboard";

export default function CrawlerPage() {
  return <CrawlerDashboard />;
}


